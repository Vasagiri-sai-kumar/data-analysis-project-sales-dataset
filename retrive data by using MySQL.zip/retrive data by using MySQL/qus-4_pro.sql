-- 4. Time Series Analysis:
-- 	a. What are the sales trends over time (monthly, quarterly, yearly)?
select date_format(`order date`,'%y-%m') as months,
		sum(sales) as total_sales
from superstore
where `Order Date` between '1/1/2014' and '1/12/2017'
group by months
order by months;

--  b. Identify peak sales periods and slow periods.