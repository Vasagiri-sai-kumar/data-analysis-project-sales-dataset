-- 2. Customer Insights:
-- 	a. Who are the top 10 customers by sales?
select `Customer ID` ,
		`Customer Name`,
        sum(Sales) as total_sales
from superstore
group by `Customer ID`,`Customer Name`
order by total_sales
limit 10;
-- 	b. How do sales and profit vary across different customer segments?
select Segment,
		sum(Sales) as Total_sales,
        SUM(Profit) as Total_profit
from superstore
group by Segment;
