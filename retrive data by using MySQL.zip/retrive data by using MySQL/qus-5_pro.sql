-- 5. Product Analysis:
-- a. Which product categories and sub-categories are the most and least profitable?
select Category,
		-- `Sub-Category`,
        sum(profit) as Total_profit
from superstore
group by Category;-- `Sub-Category`;

select 
		`Sub-Category`,
        sum(profit) as Total_Profit
from superstore
group by `Sub-Category`
order by Total_profit;

-- b.  Analyze the impact of discounts on sales and profit.
select Discount,
		sum(Sales) as total_sales,
        sum(profit) as total_profit
from superstore
group by Discount
order by discount;










