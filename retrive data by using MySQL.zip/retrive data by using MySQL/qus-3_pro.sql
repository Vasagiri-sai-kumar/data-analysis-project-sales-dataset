-- 4. Geographical Analysis:
-- 	a. Which regions generate the most sales?
select region ,
		sum(Sales) as most_sales
from superstore
group by region
order by most_sales desc;
-- 	b. How do sales and profit vary by state and city?
select state,
		city,
        sum(Sales) as Total_sales,
        sum(Profit) as Total_profit
from superstore
group by city,State;