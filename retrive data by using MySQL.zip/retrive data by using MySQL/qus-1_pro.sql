select * from superstore;
-- 1. Sales Performance:
-- 	  a.What are the total sales and profit for the entire dataset?
select sum(Sales) as total_Sales,
		sum(Profit) as total_Profit
from superstore;
--    b.Which products have the highest and lowest sales?
select Category, 
		max(Sales) as highest_sales,
        min(Sales) as lowest_sales
from superstore
group by Category;


