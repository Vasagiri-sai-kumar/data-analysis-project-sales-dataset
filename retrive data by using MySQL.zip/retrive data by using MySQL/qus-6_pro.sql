-- 6. Shipping and Delivery:
-- 	a. How does the ship mode affect sales and profit?
select `Ship Mode`,
		sum(sales)  as Total_sales,
        sum(Profit) as Total_profit
from superstore
group by `Ship Mode`
order by `Ship Mode`;

-- Which products have the highest and lowest profit margins?
select `Customer ID`,
		Category,
        Sales,
        profit,
        round((sales/profit)*100,2) as profit_margins
from superstore
order by profit_margins desc; 




